/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class SpecCat extends Cat {
    private int nose;

    public SpecCat() {
    }

    public SpecCat(int nose) {
        this.nose = nose;
    }

    public SpecCat(String area, int leg,int nose) {
        super(area, leg);
        this.nose = nose;
    }

    @Override
    public String toString() {
        return super.getArea()+","+super.getLeg()+","+nose;
    }

    public int getValue() {
        if (super.getArea().charAt(1) =='X')
        {
            return nose+9;
        }
        else return nose+6;
    }

    public void setData() {
        super.setArea(super.getArea().substring(0,super.getArea().length()-1)+"BC"+super.getArea().substring(super.getArea().length()-1));
    }
    
    
}
