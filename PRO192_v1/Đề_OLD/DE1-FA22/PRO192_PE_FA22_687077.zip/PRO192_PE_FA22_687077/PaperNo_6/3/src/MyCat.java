
import java.util.Collections;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class MyCat implements ICat{

    @Override
    public int f1(List<Cat> list) {
        
        int count=0;
        for (int i=0;i<list.size();i++)
        {
            if(list.get(i).getArea().contains("A") || list.get(i).getArea().contains("B"))
                count++;
        }
        return count;
    }


    @Override
    public void f2(List<Cat> list) {
         int max=list.get(0).getLeg();
         int pos=0;
         for (int i=0;i<list.size();i++)
         {
             if (list.get(i).getLeg()>max)
             {
                 max=list.get(i).getLeg();
                 pos=i;
             }
         }
         for (int i=pos+1;i<list.size();i++)
         {
             if (list.get(i).getLeg()==max)
             {
                 list.remove(i);
                 break;
             }
         }
    }

    @Override
    public void f3(List<Cat> list) {
         for (int i=0;i<4;i++)
         {
             for (int j=i+1;j<4;j++)
             {
                 if (list.get(i).getLeg() %10 > list.get(j).getLeg()%10)
                 {
                     Collections.swap(list, i, j);
                 }
             }
         }
    }
    
}
