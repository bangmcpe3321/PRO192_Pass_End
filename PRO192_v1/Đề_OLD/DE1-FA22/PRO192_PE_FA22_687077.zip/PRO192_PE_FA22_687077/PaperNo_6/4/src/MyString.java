import java.util.*;
import java.util.Collections;
import static java.util.Collections.list;
import java.util.Comparator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class MyString implements IString {

    public boolean check(String n){
        int count=0;
        for (int i=0;i<n.length();i++)
        {
            if (Character.isDigit(n.charAt(i)))
                count++;
        }
        return count==2;
    }
    @Override
    public int f1(String str) {
        int count=0;
        String words[] = str.split(" ");
        for (int i=0;i<words.length;i++)
        {
            if (check(words[i])==true)
            {
                count++;
            }
        }
        return count;
    }
    
    

    @Override
    public String f2(String str) {

        String n=null;
        String words[] = str.split(" ");
        Map<String, Integer> occurrences = new HashMap<>();

        for (String s : words) {
            if (occurrences.containsKey(s)) {
                occurrences.put(s, occurrences.get(s) + 1);
            } else {
                occurrences.put(s, 1);
            }
        }
        for (int i = 0; i < words.length; ++i) {
            if (occurrences.get(words[i]) == 3) {
                n = words[i];
                break;
            }
        }
        if (n == null) return str;
        for (int i = 0; i < words.length; ++i) {
            if (words[i].equals(n)) {
                words[i] = "V";
            }
        }
        String sentence = String.join(" ", words);
        return sentence;
    }
    
}
