/*              
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class MyString implements IString {

    public boolean oddDigit(String n){
        int count=0;
        for (int i=0;i<n.length();i++)
        {
            if (Character.isDigit(n.charAt(i)) && n.charAt(i)%2!=0)
            {
                count++;
            }
        }
        return count>=1;
    }
    @Override
    public int f1(String str) {
        int count=0;
        String words[] = str.split(" ");
        for (int i=0;i<words.length;i++)
        {
            if (oddDigit(words[i]))
            {
                count++;
            }
        }
        return count;
    }
    public boolean palindrom(String n){
        for (int i=0;i<n.length();i++)
        {
            if (n.charAt(i)!= n.charAt(n.length()-i-1))
            {
                return false;              
            }
        }
        return true;
    }
    @Override
    public String f2(String str) {
        String words[] = str.split(" ");
        int pos=0;
        for (int i=0;i<words.length;i++)
        {
            if (palindrom(words[i]) == true)
            {       
                pos=i;
                break;
            }
        }
      
        return str.replaceFirst(words[pos], "XX");
    }
    
}
