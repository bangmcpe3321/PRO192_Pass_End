
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class MyBrick implements IBrick {

    @Override
    public int f1(List<Brick> t) {
        int count=0;
        for (int i=0;i<t.size();i++)
        {
            if (Character.isDigit(t.get(i).getPlace().charAt(0)) && Character.isLetter(t.get(i).getPlace().charAt(t.get(i).getPlace().length()-1)))
                count++;
        }
        return count;
    }

    @Override
    public void f2(List<Brick> t) {
        int max = 0;
        int pos=0;
        for (int i=0;i<t.size();i++)
        {
            if (t.get(i).getPrice()%2!=0)
            {
              max=t.get(i).getPrice();
              break;
            }
        }
         for (int i=0;i<t.size();i++)
         {
             if (t.get(i).getPrice()>max && t.get(i).getPrice()%2!=0)
             {
                 max=t.get(i).getPrice();
                 pos=i;
             }
         }
         t.get(pos).setPlace("XX");
    }

    @Override
    public void f3(List<Brick> t) {
        int max=t.get(0).getPrice();
        int pos=0;
        for (int i=0;i<t.size();i++)
        {
            if (t.get(i).getPrice()>max)
            {
                max=t.get(i).getPrice();
                pos=i;
            }
        }
        for (int i=0;i<pos;i++)
        {
            for (int j=i+1;j<pos;j++)
            {
                if (t.get(i).getPrice()>t.get(j).getPrice())
                {
                    Collections.swap(t, i, j);
                }
            }
        }
       
    }
    
}
