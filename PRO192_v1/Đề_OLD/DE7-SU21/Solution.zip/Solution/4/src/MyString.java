/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class MyString implements IString {

    @Override
    public int f1(String str) {
         int count=0;
         str.toLowerCase();
         String words[] = str.split(" ");
         for (int i=0;i<words.length;i++)
         {
             if (words[i].endsWith("m")|| words[i].endsWith("n"))
             {
                 count++;
             }
         }
         return count;
    }

    @Override
    public String f2(String str) {
        String words[] = str.split(" ");
        int pos=0;
        int max=words[0].length();
        for (int i=0;i<words.length;i++)
        {
            if (words[i].length()>max)
            {
                max=words[i].length();
                pos=i;
            }
        }
        char c;
        String reverst=" ";
        for (int i=words[pos].length()-1;i>=0;i--)
        {
            c=words[pos].charAt(i);
            reverst=reverst+c;
        }
        return str.replaceFirst(words[pos], reverst);
        
    }
    
}
