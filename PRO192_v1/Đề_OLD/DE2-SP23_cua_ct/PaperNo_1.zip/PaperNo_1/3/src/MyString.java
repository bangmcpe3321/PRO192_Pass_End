/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class MyString implements IString {
    public boolean check(String n){
        int count=0;
        for (int i=0;i<n.length();i++)
        {
            if (n.charAt(i)>='0' && n.charAt(i)<='9' && n.charAt(i)%2==0)
            {
                count++;
            }
        }
        return count>=1;
    }

    @Override
    public int f1(String str) {
        int count=0;
        String words[] = str.split("\\s");
        for (int i=0;i<words.length;i++)
        {
            if (check(words[i]))
            {
                count++;
            }
        }
        return count;
    }

    public boolean palindrome(String n){
        for (int i=0;i<n.length();i++)
        {
            if (n.charAt(i)!= n.charAt(n.length()-i-1))
            {
                return false;
            }
        }
        return true;
    }
    @Override
    public String f2(String str) {
        boolean find=false;
        String words[]=str.split(" ");
        int pos=0;
         for (int i=0;i<words.length;i++)
         {
             if (palindrome(words[i])==true)
             {
                  pos=i;
                  find=true;
                  break;
             }
             
         }
         if (find == false) return str;
          return str.replaceFirst(words[pos], "YY");
        
         
    }
    
}
