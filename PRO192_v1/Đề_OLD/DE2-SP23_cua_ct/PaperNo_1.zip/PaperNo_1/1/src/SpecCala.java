

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class SpecCala extends Cala{
    private int color;

    public SpecCala() {
    }

    public SpecCala(int color) {
        this.color = color;
    }

    public SpecCala(String owner, int price,int color) {
        super(owner, price);
        this.color = color;
    }

    @Override
    public String toString() {
        return super.getOwner()+"@"+super.getPrice()+"@"+color;
    }

    public int getValue() {
        if (color % 2 == 0) return super.getPrice()+1;
        else return super.getPrice()*2;
    }

    public void setData() {
        String words[] = super.getOwner().split("\\s");
        for (int i=0;i<words.length;i++)
        {
           words[i]=Character.toUpperCase(words[i].charAt(0))+words[i].substring(1);
        }
        super.setOwner(String.join(" ", words));
    }
    
    
}
