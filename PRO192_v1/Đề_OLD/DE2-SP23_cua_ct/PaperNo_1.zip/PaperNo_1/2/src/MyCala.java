
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class MyCala implements ICala {

    @Override
    public int f1(List<Cala> t) {
        int count=0;
        for(int i=0;i<t.size();i++)
        {
            if ( t.get(i).getPrice()%2==0)
            {
                count++;
            }
        }
        return count;
    }

    @Override
    public void f2(List<Cala> t) {
        int min=t.get(0).getPrice();
        int pos=0;
        for (int i=0;i<t.size();i++)
        {
            if(t.get(i).getPrice()<min)
            {
                min=t.get(i).getPrice();
                pos=i;
            }
        }
         for (int i=pos+1;i<t.size();i++)
        {
            if(t.get(i).getPrice()==min)
            {
                t.remove(i);
                break;
            }
        }
    }

    @Override
    public void f3(List<Cala> t) {
         Collections.sort(t, new Comparator<Cala>(){
             @Override
             public int compare(Cala o1, Cala o2) {
                  if (o1.getOwner().charAt(0)-(o2.getOwner().charAt(0))!=0)
                  {
                      return -(o1.getOwner().charAt(0)-(o2.getOwner().charAt(0)));
                  }
                 return 0;
             }
             
         });
     

    }
    
}
