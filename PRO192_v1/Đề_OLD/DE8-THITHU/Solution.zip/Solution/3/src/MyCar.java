
import java.util.*;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Trang
 */
public class MyCar implements ICar{

    @Override
    public int f1(List<Car> t) {
       int count=0;
       for (int i=0;i<t.size();i++)
       {
           count=count+t.get(i).getRate();
       }
       return count/t.size();
    }

    @Override
    public void f2(List<Car> t) {
        int max=t.get(0).getRate();
        int pos=0;
        int pos2=0;
        int min=t.get(0).getRate();
       for (int i=0;i<t.size();i++)
       {
           if (max<t.get(i).getRate())
           {
               max=t.get(i).getRate();
               pos=i;
           }
       }
       for (int i=0;i<t.size();i++)
       {
           if (min>t.get(i).getRate())
           {
               min=t.get(i).getRate();
               pos2=i;
           }
       }
       Collections.swap(t, pos2, pos);
    }

    @Override
    public void f3(List<Car> t) {
       Collections.sort(t, new Comparator<Car>(){     
            @Override
            public int compare(Car o, Car o1) {
                if(o.getMaker().compareTo(o1.getMaker()) != 0){
                    return o.getMaker().compareTo(o1.getMaker());
                } else return -(o.getRate() - o1.getRate());
            }
            
        });
    }
           
           

   
}

  
    
    

