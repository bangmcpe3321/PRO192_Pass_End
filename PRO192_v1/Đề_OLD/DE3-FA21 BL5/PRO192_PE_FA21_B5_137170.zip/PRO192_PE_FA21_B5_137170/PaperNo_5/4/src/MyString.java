                    
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PC
 */
public class MyString implements IString {

    @Override
    public int f1(String str) {
       int count=0;
       String words[] =str.split(" ");
       for (int i=0;i<words.length;i++)
       {
           if (Character.isDigit(words[i].charAt(words[i].length()-1)))
               count++;
       }
       return count;
    }

    @Override
    public String f2(String str) {
         String words[] =str.split(" ");
         for (int i=words.length-4;i<=words.length-1;i++)
         {
             for(int j = i+1; j <= words.length-1;++j){
                 if (words[i].compareTo(words[j]) > 0) {
                     String s = words[i];
                     words[i] = words[j];
                     words[j] = s;
                 }
             }
         }
         String sentence = String.join(" ", words);
        return sentence.trim();

         
    }

   
}
