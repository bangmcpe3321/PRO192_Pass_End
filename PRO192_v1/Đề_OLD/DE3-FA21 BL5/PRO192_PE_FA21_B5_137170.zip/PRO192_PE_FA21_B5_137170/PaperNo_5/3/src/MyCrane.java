
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author PC
 */
public class MyCrane implements ICrane {

    @Override
    public int f1(List<Crane> list) {
         int count=0;
         for (int i=0;i<list.size()-1;i++)
         {
             if (list.get(i).getPrice() < list.get(i+1).getPrice())
                 count++;
         }
         return count;
    }

    @Override
    public void f2(List<Crane> list) {
      boolean flag = false;
      int max=0;
      int pos=0;
        for (int i = 0; i < list.size(); i++) {
            for (int j = i+1; j < list.size(); j++) {
                if(list.get(i).getPrice() == list.get(j).getPrice() &&flag==false){
                        list.get(i).setOwner("T");
                        list.get(j).setOwner("T");
                        max=list.get(j).getPrice();
                        pos=j;
                        flag=true;
                   
                }
                
            }    
        }
        for (int i = pos; i < list.size(); i++) {
            if (max==list.get(i).getPrice())
            {
                list.get(i).setOwner("T");
            }
        }
    }



    @Override
    public void f3(List<Crane> list) {
       Collections.sort(list.subList(0, 5), new Comparator<Crane>(){
           @Override
           public int compare(Crane o1, Crane o2) {
               if ((o1.getPrice()%10)-(o2.getPrice()%10)!=0)
               {
                   return (o1.getPrice()-(o2.getPrice()));
               }
              // else return (o1.getPrice()-o2.getPrice());
               return 0;
           }
       });
               }
           
//       });
//for (int i=0;i<5;i++)
//    for (int j=i+1;j<5;j++)
//    {
//        if (list.get(i).getPrice() %10 >list.get(j).getPrice() %10)
//            Collections.swap(list, i, j);
//    }
//
// for (int i=0;i<5;i++)
//       {
//           for (int j=i+1;j<5;j++)
//           {
//               if (list.get(i).getPrice()%10 < list.get(j).getPrice()%10)
//               {
//                   Collections.swap(list, i, j);
//               }
//           }
//       }
//    }
}
               

