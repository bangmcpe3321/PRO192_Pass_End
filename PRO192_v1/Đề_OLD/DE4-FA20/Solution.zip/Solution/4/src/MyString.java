/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class MyString implements IString
{

    @Override
    public int f1(String str) {
       int count=0;
       for (int i=0;i<str.length();i++)
       {
           if (str.charAt(i)=='2' || str.charAt(i)=='3'||str.charAt(i)=='5' || str.charAt(i)=='7')
               count++;
       }
       return count;
    }

    @Override
    public String f2(String str) {
        String words[] = str.split(" ");
        String c="";
        for (int i=words.length-1;i>=0;i--)
        {
            c+=words[i]+" ";
        }
        return c;
    }
    
}
