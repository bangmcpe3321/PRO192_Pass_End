
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class MyCar implements ICar {

    @Override
    public int f1(List<Car> t) {
       int count=0;
       for (int i=0;i<t.size();i++)
       {
           count+=t.get(i).getRate();
       }
       return count/t.size();
    }

    @Override
    public void f2(List<Car> t) {
       int max=t.get(0).getRate();
       int min=t.get(0).getRate();
       int pos1=0;
       int pos2=0;
       for (int i=0;i<t.size();i++)
       {
          if(max>t.get(i).getRate())
          {
              max=t.get(i).getRate();
              pos1=i;
          }
       }
       for (int i=0;i<t.size();i++)
       {
          if(min<t.get(i).getRate())
          {
              min=t.get(i).getRate();
              pos2=i;
          }
       }
       Collections.swap(t, pos1, pos2);
    }

    @Override
    public void f3(List<Car> t) {
        Collections.sort(t, new Comparator<Car>(){
            @Override
            public int compare(Car o1, Car o2) {
                if (o1.getMaker().compareTo(o2.getMaker())!=0)
                {
                    return o1.getMaker().compareTo(o2.getMaker());
                }
                else return -(o1.getRate()-o2.getRate());
            }
            
        });
    }
    
}
