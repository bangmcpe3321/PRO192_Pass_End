
public class SpecRobot extends  Robot
{
    int step;

    public SpecRobot() {
    }
    public SpecRobot(String label,int type,int step)
    {
        super.setLabel(label);
        super.setType(type);
        this.step = step;
    }
    
    public void setData() 
    {
  //  super.setLabel(super.getLabel().substring(0,1)+step+super.getLabel().substring(1,super.getLabel().length()));
    super.setLabel(super.getLabel().substring(0,1)        
            + step + super.getLabel().substring(1));
            
            
    
    }
    public int getValue() 
    {
    int type = super.getType();
    String label = super.getLabel();

    if (type < 3 && label.contains("A")) {
        return step;
    } else {
        return step + 2;
    }
    }
    @Override
    public String toString()
    {
        return super.getLabel()+", " + super.getType()+", " + this.step;
    }
}
