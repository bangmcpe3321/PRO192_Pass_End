
import java.util.List;
import java.util.Collections;
import java.util.Comparator;

public class MyRobot implements IRobot {

    @Override
    public int f1(List<Robot> t) {
        int count = 0;
        for (int i = 0; i < t.size(); i++) {
            if (!t.get(i).getLabel().contains("A") && !t.get(i).getLabel().contains("B")) {
                count += t.get(i).getStep();
            }
        }
        return count;
    }

    @Override
    public void f2(List<Robot> t) {
        int min = t.get(0).getStep();
        for (int i = 0; i < t.size(); i++) {
            int currentStep = t.get(i).getStep();
            if (currentStep % 2 != 0) {
                min = currentStep;
                System.out.println(min);
                break; // Exit the loop once the first odd number is found
            }
        }
        for (int i = 0; i < t.size(); i++) {
            if (t.get(i).getStep() % 2 != 0 && t.get(i).getStep() <= min) {
                t.remove(i);
                break;
            }

        }
    }

    @Override
    public void f3(List<Robot> t) {
//        Collections.sort(t.subList(1, 5), new Comparator<Robot>() {
//            @Override
//            public int compare(Robot r1, Robot r2) {
//                if (r1.getStep() == r2.getStep()) {
//                    return r2.getLabel().compareTo(r1.getLabel());
//                }
//                return r1.getStep() - r2.getStep();
//            }
//        });
    Collections.sort(t.subList(1, 5),new Comparator<Robot>() {
        @Override
        public int compare(Robot o1, Robot o2) {
           if(o1.getLabel().compareTo(o2.getLabel())!=0){
               return o1.getLabel().compareTo(o2.getLabel());
           }
           return o1.getStep() - o2.getStep();
        }
    });
    }

}
