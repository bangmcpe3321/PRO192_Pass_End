




public class Engine 
{
    String designer;
    int power;

    public Engine() {
    }
    public Engine(String designer, int power)
    {
        this.designer = designer;
        this.power = power;
    }
    public String getDesigner() {
//        String s="";
//   //   return designer.substring(0,1).toLowerCase()+designer.substring(1,3);
//   for (int i=0;i<designer.length();i++){
//      if (Character.isDigit(designer.charAt(i)) && designer.charAt(i)%2==0){
//          s+=designer.charAt(i);
//      }
//    }
//   return s;
//return designer.substring(designer.length()-3);
//    }
//    public void setDesigner(String designer) {
//        this.designer = designer;
//    }
    }
    public int getPower() {
        return power;
    }

    public void setPower(int power) {
        this.power = power;
    }
    
    
}
