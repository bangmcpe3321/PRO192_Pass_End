
import java.util.Collections;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class MyCoffee implements ICoffee {

    @Override
    public int f1(List<Coffee> t) {
         int count=0;
         for (int i=0;i<t.size();i++)
         {
             if (!(t.get(i).getName().contains("B") &&t.get(i).getName().contains("A") ))
                 count++;
         }
         return count;
    }

    @Override
    public void f2(List<Coffee> t) {
         int max=t.get(0).getSize();
         int pos=0;
         for (int i=0;i<t.size();i++)
         {
             if (t.get(i).getSize()>max)
             {
                 max=t.get(i).getSize();
                 pos=i;
             }
         }
         t.remove(pos);
    }

    @Override
    public void f3(List<Coffee> t) {
       for (int i=0;i<3;i++)
       {
           for (int j=i+1;j<3;j++)
           {
               if (t.get(i).getSize()%10 < t.get(j).getSize()%10)
               {
                   Collections.swap(t, i, j);
               }
           }
       }
    }
    
}
