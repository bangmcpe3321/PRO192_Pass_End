/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class MyString implements IString {

    public boolean check(String n){
        int count=0;
        for (int i=0;i<n.length();i++)
        {
            if (Character.isDigit(n.charAt(i)) && n.charAt(i)%2==0)
                count++;
        }
        return count>=2;
    }
    @Override
    public int f1(String str) {
         int count=0;
         String words[] = str.split(" ");
         for (int i=0;i<words.length;i++)
         {
             if (check(words[i]))
             {
                 count++;
             }
         }
         return count;
    }

    @Override
    public String f2(String str) {
        String words[] =str.split("\\s");
        int min=words[0].length();
        int pos2=0;
        for (int i=0;i<words.length;i++)
        {     
            if (words[i].length()<min)
            {
                min=words[i].length();
                pos2=i;
            }
        }
        int max=words[0].length();
        int pos=0;
        for (int i=0;i<words.length;i++)
        {
            if (words[i].length()>max)
            {
                max=words[i].length();
                pos=i;
            }
        }
       
        String replaceFirst = str.replaceFirst(words[pos], Integer.toString(min));
       
        return replaceFirst.trim();
        
    }
    
    
}
