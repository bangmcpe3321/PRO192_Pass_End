
import java.util.Collections;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LENOVO
 */
public class MyString implements IString {

    @Override
    public int f1(String string) {
        int count=0;
        String words[] = string.split(" ");
        
       for (int i=0;i<words.length;i++){
           if(isPalindrome(words[i]) && is3Digit(words[i])){
               count++;
           }
           
       }
       return count;
    }
    public boolean isPalindrome (String n){
        String s="";
        for (int i=n.length()-1;i>=0;i--){
            s=s+n.charAt(i);
        }
        if(s.equals(n)){
            return true;
        }else{
            return false;
        }
    }
    public boolean is3Digit(String n){
        int count=0;
        for (int i=0;i<n.length();i++){
            if(Character.isDigit(n.charAt(i))){
                count++;
            }
        }
        if (count>=3){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public String f2(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
