
import java.util.Collection;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LENOVO
 */
public class House {
    String type;
    int area;

    public House() {
    }

    public House(String type, int area) {
        this.type = type;
        this.area = area;
    }

   public String getType() {
    String s = "";
    for (int i = type.length()-1; i >= type.length()-3; i--) { 
        s = s + type.charAt(i); 
    }
    return s;
    }


    public void setType(String type) {
        this.type = type;
    }

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = 3*area;
    }
    
}
