/*  
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LENOVO
 */
public class SpecLift extends Lift {

    int load;

    public SpecLift() {
    }

    public SpecLift(String label, int type, int load) {
        super(label, type);
        this.load = load;
    }

    public int getValue() {
        if (super.getLabel().contains(Integer.toString(super.getType()))) {
            return super.getType() + load;
        } else {
            return load;
        }
    }

    public void setData() {
        String s = "";
        for (int i = 0; i < super.getLabel().length(); i++) {
            if (i % 2 == 0) {
                s += super.getLabel().charAt(i);
            }
        }
        super.setLabel(s);
    }

    @Override
    public String toString() {
        return "SpecLift{" + "load=" + load + '}';
    }

}
