
import java.util.Collections;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LENOVO
 */
public class MyLift implements ILift {

   @Override
public int f1(List<Lift> t) {
    int max = Integer.MIN_VALUE;
    for (int i=0;i<t.size();i++) {
        if (isPrime(t.get(i).getLabel().length()) && t.get(i).getLoad() > max) {
            max = t.get(i).getLoad();
        }
    }
    return max;
}

public boolean isPrime(int number) {
    if (number <= 1) {
        return false;
    }
    for (int i = 2; i  < number; i++) {
        if (number % i == 0) {
            return false;
        }
    }
    return true;
}


    @Override
    public void f2(List<Lift> t) {
       for (int i=0;i<5;i++){
           Collections.reverse(t.subList(0, 5));
       }
    }

    @Override
    public void f3(List<Lift> t) {
        int count=0;
       for (int i=0;i<t.size();i++){
           if(t.get(i).getLoad()<20){
               count+=1;
           }
           if(count==2){
               t.remove(i);
               break;
           }
       }
    }
    
}
